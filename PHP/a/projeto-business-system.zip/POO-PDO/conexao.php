<?php

    // MySQL
    $db = new PDO("mysql:host=localhost;dbname=pdo", "root", "");
  
?>